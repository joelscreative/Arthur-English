This folder contains a sample CSS "skin" for the Shape theme. I whipped it up specifically for this tutorial, to give you an example of CSS in action. The best way to learn is to look at the styles and to get a feel for what changes what. 

This design is released under the GPL, so by all means, build on top of it, use it, or do whatever you like with it. It's yours to wrangle.

INSTRUCTIONS

1. In your WordPress installation, navigate to the Shape theme folder (either via FTP or on your local machine).

2. Once in the Shape folder, rename "rtl.css" and "style.css" to whatever you like. Or move them to another folder, whatever is easiest for you. This step is optional; I've included it just in case you want to restore the plain stylesheets after taking a look at the sample design.

3. Drag the "style.css" and "rtl.css" contained in shape-sample-style into your Shape theme directory. You can also replace "screenshot.png", it's your choice. 

Enjoy!